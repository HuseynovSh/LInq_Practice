﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AutoClub.Models
{
    public class Test
    {
        public int Id { get; set; }
        public bool t1 { get; set; } = false;
        public bool t2 { get; set; }  
    }
}
